# Random Letter Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/teddimagg/pen/NPZmje](https://codepen.io/teddimagg/pen/NPZmje).



Forked from [brandonisgreen](http://codepen.io/brandonisgreen/)'s Pen [Random Letter Effect](http://codepen.io/brandonisgreen/pen/CHJza/).